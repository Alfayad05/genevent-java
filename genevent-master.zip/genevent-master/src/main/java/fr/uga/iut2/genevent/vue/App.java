package fr.uga.iut2.genevent.vue;

import javafx.application.Application;
import javafx.stage.Stage;

public class App extends Application {
    public static App application;

    static {
        new App();
    }

    public App() {
        application = this;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

    }
}
